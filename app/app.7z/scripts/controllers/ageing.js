'use strict';

/**
 * @ngdoc function
 * @name equismsApp.controller:AgeingCtrl
 * @description
 * # AgeingCtrl
 * Controller of the equismsApp
 */
angular.module('equismsApp')
  .controller('AgeingCtrl', function ($scope) {
    $scope.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
