'use strict';

/**
 * @ngdoc function
 * @name equismsApp.controller:WarisCtrl
 * @description
 * # WarisCtrl
 * Controller of the equismsApp
 */
angular.module('equismsApp')
  .controller('WarisCtrl', function ($scope) {
    $scope.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
